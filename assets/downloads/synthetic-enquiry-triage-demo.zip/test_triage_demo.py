import unittest
from triage_demo import triage

def row(**changes):
    result = dict(enquiry_id='D1', business_email='buyer@example.com', problem='Map intake', drawing_required='yes', drawing_received='yes')
    result.update(changes)
    return result

class DeliveryChecks(unittest.TestCase):
    def test_routes_complete_and_incomplete_inputs(self):
        result = triage([row(), row(enquiry_id='D2', drawing_received='no')])
        self.assertEqual([r['owner_queue'] for r in result['accepted']], ['technical_review', 'intake'])
    def test_exact_duplicate_retains_one_work_item(self):
        result = triage([row(), row()])
        self.assertEqual(result['counts'], {'input': 2, 'accepted': 1, 'rejected': 0, 'duplicates': 1})
    def test_conflicting_duplicate_requires_reconciliation(self):
        result = triage([row(), row(problem='Different request')])
        self.assertEqual(len(result['accepted']), 1)
        self.assertIn('Conflicting', result['rejected'][0]['reason'])
    def test_invalid_email_and_missing_problem_rejected(self):
        result = triage([row(business_email='bad'), row(problem='')])
        self.assertEqual(result['counts']['rejected'], 2)
    def test_invalid_boolean_does_not_route_as_complete(self):
        result = triage([row(drawing_received='unknown')])
        self.assertEqual(result['counts']['accepted'], 0)
    def test_missing_column_rejected(self):
        candidate = row()
        del candidate['drawing_required']
        self.assertEqual(triage([candidate])['counts']['rejected'], 1)
    def test_invalid_first_row_does_not_hide_later_valid_record(self):
        result = triage([row(business_email='bad'), row()])
        self.assertEqual(result['counts']['accepted'], 1)
    def test_empty_batch_stays_zero(self):
        self.assertEqual(triage([])['counts'], {'input': 0, 'accepted': 0, 'rejected': 0, 'duplicates': 0})

if __name__ == '__main__':
    unittest.main()
