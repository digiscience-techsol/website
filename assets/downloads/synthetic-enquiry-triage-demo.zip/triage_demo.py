#!/usr/bin/env python3
"""Synthetic enquiry handoff prototype. Local only; never sends or stores live leads."""
import argparse
import csv
import json
import re
from pathlib import Path

REQUIRED = {'enquiry_id', 'business_email', 'problem', 'drawing_required', 'drawing_received'}

def triage(rows):
    accepted, rejected, duplicates, seen = [], [], [], {}
    for number, row in enumerate(rows, start=2):
        cleaned = {k: str(v or '').strip() for k, v in row.items() if k is not None}
        missing = REQUIRED - cleaned.keys()
        reason = None
        if missing:
            reason = 'Missing required columns: ' + ', '.join(sorted(missing))
        elif not cleaned['enquiry_id']:
            reason = 'Missing enquiry ID'
        elif not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', cleaned['business_email']):
            reason = 'Invalid email format; deliverability not tested'
        elif not cleaned['problem']:
            reason = 'Missing problem description'
        elif any(cleaned[k].lower() not in {'yes', 'no'} for k in ('drawing_required', 'drawing_received')):
            reason = 'Drawing fields must be yes or no'
        if reason:
            rejected.append({'line': number, 'enquiry_id': cleaned.get('enquiry_id'), 'reason': reason})
            continue
        ident = cleaned['enquiry_id']
        if ident in seen:
            if seen[ident] == cleaned:
                duplicates.append({'line': number, 'enquiry_id': ident, 'reason': 'Exact repeat; one work item retained'})
            else:
                rejected.append({'line': number, 'enquiry_id': ident, 'reason': 'Conflicting duplicate ID; manual reconciliation required'})
            continue
        seen[ident] = cleaned
        missing_drawing = cleaned['drawing_required'].lower() == 'yes' and cleaned['drawing_received'].lower() == 'no'
        accepted.append({'enquiry_id': ident, 'status': 'needs_information' if missing_drawing else 'ready_for_review',
                         'owner_queue': 'intake' if missing_drawing else 'technical_review',
                         'next_action': 'Request the required drawing through an approved channel' if missing_drawing else 'Review feasibility and agree scope',
                         'contact_validation': 'format_only'})
    return {'mode': 'synthetic_local_demonstration', 'accepted': accepted, 'rejected': rejected,
            'duplicates': duplicates, 'counts': {'input': len(rows), 'accepted': len(accepted),
            'rejected': len(rejected), 'duplicates': len(duplicates)},
            'limitations': ['No messages sent', 'No attachment inspected', 'No CRM integration or identity verification',
                            'Queue labels are not staffing or SLA evidence', 'No customer outcomes measured']}

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('input', type=Path)
    p.add_argument('--out', required=True, type=Path)
    args = p.parse_args()
    with args.input.open(newline='') as stream:
        reader = csv.DictReader(stream)
        if not REQUIRED.issubset(set(reader.fieldnames or [])):
            p.error('Input CSV lacks required columns')
        rows = list(reader)
    result = triage(rows)
    args.out.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result['counts']))

if __name__ == '__main__':
    main()
