DigiScience synthetic enquiry triage demonstration

These eight records are invented. No live leads or customer records are included.
Requires Python 3; no third-party packages or network connection.

Reproduce locally after inspecting the source:
python3 triage_demo.py synthetic-enquiries.csv --out result.json
python3 -m unittest -v test_triage_demo.py

Compare result.json with expected-result.json. Expected counts: input8, accepted5, rejected2, duplicates1. Three work items enter technical_review and two enter intake. These are illustrative queue labels, not delivered messages or staffed assignments.

Email validation checks format only. No attachments, CRM, identity, cross-run persistence or production integration are tested. Duplicates are checked only within one run. If an ID is repeated with changed content, the earlier item remains retained and the later item is rejected for manual reconciliation; neither version should be used downstream until resolved.

The eight automated tests check local routing and failure cases. They establish no customer outcome, security certification, measured savings or readiness for production. Coding and a working proof of concept are outside the separately offered Solution Assessment.

Source: DigiScience internal synthetic demonstration, first created20September2026. Public proof page: https://digisciencetechsol.com/guides/manufacturing-enquiry-workflow/#synthetic-triage
